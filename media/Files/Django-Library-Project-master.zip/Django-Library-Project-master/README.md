# Django-Library-Project
The project is a step by step Django project creation to reproduce the management of a library

### How to run the project
1. Download the repo
2. Unzip
3. activate the virtual environment ```library_env\Scripts\activate```
4. start the Django web server ```python library-project\libraryproject\manage.py runserver```
5. open browser and use URL 127.0.0.1:8000 for the homepage and 127.0.0.1:8000/admin to access to admin panel

- You can follow the guide DjangoLibraryProject-ITA doc file to develop by yourself
